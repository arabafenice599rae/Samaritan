# Samaritan Core - Heavy/Core NeuroNode

Implementazione completa del NeuroNode Heavy/Core per Samaritan 1.5.

## 📁 Struttura del progetto

```
core/
├── Cargo.toml
└── src/
    ├── lib.rs                    # Entry point, NeuroNode struct
    ├── node_profile.rs          # ✅ COMPLETO - Hardware detection
    ├── adaptive_throttle.rs     # ✅ COMPLETO - PID throttling
    ├── scheduler.rs             # ✅ COMPLETO - Priority scheduler
    ├── io_layer.rs              # 🚧 STUB - I/O verso utente
    ├── neural_engine.rs         # 🚧 STUB - ONNX backend
    ├── policy_core.rs           # 🚧 STUB - Safety policies
    ├── federated.rs             # 🚧 STUB - Federated learning
    ├── net.rs                   # 🚧 STUB - Network client
    ├── meta_observer.rs         # 🚧 STUB - Metrics
    ├── meta_brain.rs            # 🚧 STUB - ADR & distillation
    ├── snapshot_store.rs        # 🚧 STUB - Model snapshots
    ├── update_agent.rs          # 🚧 STUB - Binary updates
    └── node.rs                  # 🚧 STUB - Config & runner
```

## ✅ Moduli completi (production-ready)

### 1. `node_profile.rs`
**Auto-detection del profilo hardware del nodo**

- **Profili**: HeavyGpu, HeavyCpu, Desktop, Mobile
- **Detection**: CPU cores, RAM, GPU dedicata (Linux via sysfs)
- **Metadata**: `compute_power()`, `max_parallel_workers()`, `can_train()`
- **Test**: 12 test completi
- **LOC**: ~500 linee

**Esempio:**
```rust
let profile = NodeProfileDetector::detect();
if profile.is_heavy() {
    // Nodo può fare training federato
}
```

### 2. `adaptive_throttle.rs`
**Sistema di throttling adattivo con PID controller**

- **Livelli**: Normal, Throttled, Survival
- **PID**: Proporzionale, Integrale, Derivativo
- **Metriche**: Latenza tick, intensità computazionale
- **Configurazione**: Preset per Heavy/Desktop/Mobile
- **Test**: 15 test completi
- **LOC**: ~600 linee

**Esempio:**
```rust
let mut throttle = AdaptiveThrottle::new();
throttle.update(&profile);
throttle.record_tick_latency(latency);

if throttle.allow_background() {
    // Esegui training/snapshot
}
```

### 3. `scheduler.rs`
**Priority scheduler a tre corsie**

- **Lane**: Critical (inferenza), Normal (training), Background (snapshot/meta)
- **Task**: 10 tipi di task schedulabili
- **Scheduling**: Periodico basato su tick_number
- **Budget**: Controllo del carico per tick
- **Test**: 14 test completi
- **LOC**: ~550 linee

**Esempio:**
```rust
let mut scheduler = PriorityScheduler::new();
let work = scheduler.schedule_tick(tick_number);

for task in work.tasks {
    match task {
        TaskKind::UserInference => { /* ... */ }
        TaskKind::LocalTraining => { /* ... */ }
        // ...
    }
}
```

## 🚧 Moduli stub (da implementare)

I seguenti moduli hanno stub funzionanti che permettono al crate di compilare, ma l'implementazione reale è da completare:

- **io_layer**: Input/output verso utente, gestione chat/stream
- **neural_engine**: Backend ONNX per inferenza
- **policy_core**: Regole di safety/governance
- **federated**: DP-SGD, delta computation, privacy accountant
- **net**: Client HTTP/QUIC per comunicazione federata
- **meta_observer**: Raccolta metriche strutturate
- **meta_brain**: ADR (Architectural Decision Records), distillazione
- **snapshot_store**: Persistenza versionata del modello
- **update_agent**: Aggiornamenti binari con verifica firma
- **node**: Configuration loader e main loop

## 🏗️ Architettura

```
┌─────────────────────────────────┐
│         NeuroNode               │
│                                 │
│  ┌───────────────────────────┐  │
│  │   NeuralEngine (ONNX)    │  │
│  └───────────────────────────┘  │
│  ┌───────────────────────────┐  │
│  │   PolicyCore             │  │
│  └───────────────────────────┘  │
│  ┌───────────────────────────┐  │
│  │   FederatedState (DP)    │  │
│  └───────────────────────────┘  │
│  ┌───────────────────────────┐  │
│  │   AdaptiveThrottle       │  │ ← COMPLETO
│  └───────────────────────────┘  │
│  ┌───────────────────────────┐  │
│  │   PriorityScheduler      │  │ ← COMPLETO
│  └───────────────────────────┘  │
└─────────────────────────────────┘
```

## 🚀 Prossimi passi

1. **Implementare neural_engine**: Backend ONNX reale con onnxruntime
2. **Implementare policy_core**: Regole di safety complete (da samaritan-core-lite)
3. **Implementare federated**: DP-SGD kernel + privacy accountant
4. **Implementare io_layer**: Chat interface + stream handling
5. **Implementare net**: DeltaMessage + HTTP client
6. **Test di integrazione**: Creare node_daemon binario

## 📦 Dipendenze

```toml
[dependencies]
anyhow = { workspace = true }
tracing = "0.1"
tokio = { version = "1", features = ["rt-multi-thread", "macros", "time", "fs", "sync"] }
uuid = { version = "1", features = ["v4"] }
hex = "0.4"
serde = { version = "1", features = ["derive"] }
serde_yaml = "0.9"
regex = { workspace = true }
```

## 🧪 Testing

I moduli completi hanno test comprensivi:

```bash
cargo test -p samaritan-core
```

## 📄 License

MIT

---

**Status**: Work in progress - Core runtime modules completed (throttle, scheduler, profile)
